package com.example.fullstackserver;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FullstackServerApplicationTests {

    @Test
    void contextLoads() {
    }

}
